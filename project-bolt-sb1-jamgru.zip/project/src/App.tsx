import React, { useState } from 'react';
import { Search, BarChart2 } from 'lucide-react';
import TrendCard from './components/TrendCard';
import TimeFilter from './components/TimeFilter';
import CategoryFilter from './components/CategoryFilter';

const trends = [
  {
    title: "Artificial Intelligence Breakthroughs",
    category: "Technology",
    searches: "2.5M searches",
    growth: "+125%",
    image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=500&auto=format&fit=crop&q=60"
  },
  {
    title: "Sustainable Energy Solutions",
    category: "Science",
    searches: "1.8M searches",
    growth: "+82%",
    image: "https://images.unsplash.com/photo-1509391366360-2e959784a276?w=500&auto=format&fit=crop&q=60"
  },
  {
    title: "Remote Work Revolution",
    category: "Business",
    searches: "1.2M searches",
    growth: "+95%",
    image: "https://images.unsplash.com/photo-1593642532744-d377ab507dc8?w=500&auto=format&fit=crop&q=60"
  },
  {
    title: "Space Exploration Updates",
    category: "Science",
    searches: "950K searches",
    growth: "+67%",
    image: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=500&auto=format&fit=crop&q=60"
  }
];

function App() {
  const [timeRange, setTimeRange] = useState('Past 24 hours');
  const [category, setCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredTrends = trends.filter(trend => 
    (category === 'All' || trend.category === category) &&
    trend.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BarChart2 className="h-6 w-6 text-blue-600" />
              <span className="text-xl font-semibold">Trends</span>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Search trends..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex flex-col gap-6">
          <TimeFilter selected={timeRange} onSelect={setTimeRange} />
          <CategoryFilter selected={category} onSelect={setCategory} />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredTrends.map((trend, index) => (
              <TrendCard key={index} {...trend} />
            ))}
          </div>

          {filteredTrends.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500">No trends found matching your criteria</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;