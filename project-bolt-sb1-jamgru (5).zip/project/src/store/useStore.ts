import { create } from 'zustand';

interface Video {
  id: string;
  title: string;
  thumbnail: string;
  channel: {
    name: string;
    avatar: string;
    subscribers: string;
  };
  views: string;
  timestamp: string;
  duration: string;
}

interface StoreState {
  selectedVideo: Video | null;
  setSelectedVideo: (video: Video | null) => void;
  sidebarOpen: boolean;
  toggleSidebar: () => void;
}

export const useStore = create<StoreState>((set) => ({
  selectedVideo: null,
  setSelectedVideo: (video) => set({ selectedVideo: video }),
  sidebarOpen: true,
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
}));