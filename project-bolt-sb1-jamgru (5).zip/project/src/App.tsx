import React from 'react';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import VideoCard from './components/VideoCard';
import { useStore } from './store/useStore';

const videos = [
  {
    id: '1',
    title: 'Building a Modern Web Application with React and TypeScript',
    thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=800',
    channel: {
      name: 'Tech Academy',
      avatar: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=100',
      subscribers: '1.2M',
    },
    views: '256K',
    timestamp: '2 days ago',
    duration: '15:24',
  },
  {
    id: '2',
    title: 'The Future of Artificial Intelligence - 2024 and Beyond',
    thumbnail: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800',
    channel: {
      name: 'Future Insights',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100',
      subscribers: '890K',
    },
    views: '128K',
    timestamp: '5 days ago',
    duration: '21:15',
  },
  {
    id: '3',
    title: 'Learn 3D Animation in Blender - Complete Guide',
    thumbnail: 'https://images.unsplash.com/photo-1616499452581-cc7f8e3dd3c7?w=800',
    channel: {
      name: 'Creative Hub',
      avatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=100',
      subscribers: '500K',
    },
    views: '75K',
    timestamp: '1 week ago',
    duration: '32:40',
  },
];

function App() {
  const sidebarOpen = useStore((state) => state.sidebarOpen);

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <Sidebar />
      
      <main className={`pt-20 px-4 ${sidebarOpen ? 'ml-60' : 'ml-20'}`}>
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {videos.map((video) => (
              <VideoCard key={video.id} video={video} />
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;