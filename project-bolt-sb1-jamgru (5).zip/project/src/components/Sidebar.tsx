import React from 'react';
import { Home, Compass, Clock, ThumbsUp, PlaySquare, Film, Gamepad, Newspaper, Trophy, Flame } from 'lucide-react';
import { useStore } from '../store/useStore';
import { motion } from 'framer-motion';

const menuItems = [
  { icon: Home, label: 'Home' },
  { icon: Compass, label: 'Explore' },
  { icon: Clock, label: 'History' },
  { icon: ThumbsUp, label: 'Liked Videos' },
  { icon: PlaySquare, label: 'Your Videos' },
  { icon: Film, label: 'Movies' },
  { icon: Gamepad, label: 'Gaming' },
  { icon: Newspaper, label: 'News' },
  { icon: Trophy, label: 'Sports' },
  { icon: Flame, label: 'Trending' },
];

export default function Sidebar() {
  const sidebarOpen = useStore((state) => state.sidebarOpen);

  return (
    <motion.aside
      initial={{ width: sidebarOpen ? 240 : 72 }}
      animate={{ width: sidebarOpen ? 240 : 72 }}
      className="fixed left-0 top-14 h-screen bg-white z-40 overflow-y-auto scrollbar-hide"
    >
      <div className="py-2">
        {menuItems.map(({ icon: Icon, label }) => (
          <motion.button
            key={label}
            whileHover={{ backgroundColor: '#f1f1f1' }}
            className={`w-full flex items-center px-3 py-2 ${
              sidebarOpen ? 'justify-start' : 'justify-center'
            }`}
          >
            <Icon size={20} className="min-w-[20px]" />
            {sidebarOpen && <span className="ml-6 text-sm">{label}</span>}
          </motion.button>
        ))}
      </div>
    </motion.aside>
  );
}