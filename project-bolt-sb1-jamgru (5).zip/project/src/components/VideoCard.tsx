import React from 'react';
import { motion } from 'framer-motion';

interface VideoCardProps {
  video: {
    id: string;
    title: string;
    thumbnail: string;
    channel: {
      name: string;
      avatar: string;
      subscribers: string;
    };
    views: string;
    timestamp: string;
    duration: string;
  };
}

export default function VideoCard({ video }: VideoCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -5 }}
      className="cursor-pointer"
    >
      <div className="relative">
        <img
          src={video.thumbnail}
          alt={video.title}
          className="w-full aspect-video object-cover rounded-xl"
        />
        <span className="absolute bottom-2 right-2 bg-black bg-opacity-80 text-white text-xs px-2 py-1 rounded">
          {video.duration}
        </span>
      </div>
      <div className="flex gap-3 mt-3">
        <img
          src={video.channel.avatar}
          alt={video.channel.name}
          className="w-9 h-9 rounded-full"
        />
        <div>
          <h3 className="font-medium line-clamp-2">{video.title}</h3>
          <p className="text-sm text-gray-600 mt-1">{video.channel.name}</p>
          <p className="text-sm text-gray-600">
            {video.views} views • {video.timestamp}
          </p>
        </div>
      </div>
    </motion.div>
  );
}