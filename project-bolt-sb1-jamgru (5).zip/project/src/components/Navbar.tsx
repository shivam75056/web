import React from 'react';
import { Menu, Search, Video, Bell, User, Mic } from 'lucide-react';
import { motion } from 'framer-motion';
import { useStore } from '../store/useStore';

export default function Navbar() {
  const toggleSidebar = useStore((state) => state.toggleSidebar);

  return (
    <nav className="bg-white fixed w-full z-50 px-4 h-14 flex items-center justify-between">
      <div className="flex items-center gap-4">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={toggleSidebar}
          className="p-2 hover:bg-gray-100 rounded-full"
        >
          <Menu size={20} />
        </motion.button>
        <div className="flex items-center gap-1">
          <Video className="h-6 w-6 text-red-600" />
          <span className="text-xl font-semibold">YouTube</span>
        </div>
      </div>

      <div className="flex-1 max-w-2xl mx-4">
        <div className="flex">
          <div className="flex-1 flex items-center">
            <div className="w-full flex">
              <input
                type="text"
                placeholder="Search"
                className="w-full px-4 py-2 border border-gray-200 rounded-l-full focus:outline-none focus:border-blue-500"
              />
              <button className="px-6 py-2 bg-gray-50 border border-l-0 border-gray-200 rounded-r-full hover:bg-gray-100">
                <Search size={20} className="text-gray-600" />
              </button>
            </div>
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              className="ml-4 p-2 hover:bg-gray-100 rounded-full"
            >
              <Mic size={20} />
            </motion.button>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className="p-2 hover:bg-gray-100 rounded-full"
        >
          <Video size={20} />
        </motion.button>
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className="p-2 hover:bg-gray-100 rounded-full"
        >
          <Bell size={20} />
        </motion.button>
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className="p-2 hover:bg-gray-100 rounded-full"
        >
          <User size={20} />
        </motion.button>
      </div>
    </nav>
  );
}